//Dylan Moore - 100662175
//Sydney Caldwell - 100652057

#include "Text.h"
