//Dylan Moore - 100662175
//Sydney Caldwell - 100652057

#include "Time.h"

float Time::deltaTime = 0.0f;
float Time::time = 0.0f;
clock_t Time::lastClock = 0;