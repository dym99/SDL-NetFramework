//Dylan Moore - 100662175
//Sydney Caldwell - 100652057

#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

#include <string>

class Text
{
public:
	//Text(const std::string& text);
	//~Text();
	//
	//void render();
};

