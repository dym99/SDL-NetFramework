//Dylan Moore - 100662175
//Sydney Caldwell - 100652057

#pragma once
#include <ctime>

class Time {
public:
	static float deltaTime;
	static float time;
	static clock_t lastClock;
};