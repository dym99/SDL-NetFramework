#pragma once
#include <ctime>

class Time {
public:
	static float deltaTime;
	static float time;
	static clock_t lastClock;
};