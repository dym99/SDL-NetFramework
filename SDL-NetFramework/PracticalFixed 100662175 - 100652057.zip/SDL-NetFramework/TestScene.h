#pragma once
#include "Scene.h"
class TestScene : public Scene
{
	void update() override;
	void render() override;
};

