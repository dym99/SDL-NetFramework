#include "Time.h"

float Time::deltaTime = 0.0f;
float Time::time = 0.0f;
clock_t Time::lastClock = 0;